import os

import idaapi
import idautils
from malscalpel.plugin import *

def PLUGIN_ENTRY():
    return MalScalpel()
